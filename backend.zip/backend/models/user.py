# models/user.py

from app import db
